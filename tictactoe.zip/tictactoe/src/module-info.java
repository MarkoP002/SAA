/**
 * 
 */
/**
 * @author Marko
 *
 */
module tictactoe {
}