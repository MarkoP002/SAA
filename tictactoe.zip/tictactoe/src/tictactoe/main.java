package tictactoe;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		char[][] board = new char[15][15];
		Scanner move = new Scanner(System.in);
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                board[i][j] ='_';
            }
        }
        printboard(board);
        char player = 'X';
        boolean gameover=false;
        while (!gameover && possiblemoves(board) > 0) {
        		System.out.println("Enter next collumn move: ");
            	int movecol = move.nextInt();
            	System.out.println("Enter next row move: ");
            	int moverow = move.nextInt();
            	while (board[movecol][moverow]!='_') {
            		System.out.println("Enter a possible move");
        			System.out.println("Enter next collumn move: ");
                	movecol = move.nextInt();
                	System.out.println("Enter next row move: ");
                	moverow = move.nextInt();
            	}
        		if (board[movecol][moverow]=='_') {
        			board[movecol][moverow]=player;
                	if (checkwinplayer(board)) {
                		gameover=true;
                		System.out.println("Player wins!");
                		break;
                	} 
                	opponentmove(board);
                	printboard(board);
                	if (checkopponentplayer(board)) {
                		gameover=true;
                		System.out.println("Computer wins!");
                		break;
                	}
        		}
        }
        if (possiblemoves(board)<=0) {
        	System.out.println("Tie!");
        }
        
       
       

	}
	public static void printboard(char[][] board) {
		 for (char[] a : board) {
	            for (char i : a) {
	                System.out.print(i + "   ");
	            }
	            System.out.println("\n");
	        }
	}
	public static boolean checkwinplayer(char[][] board) {
		int win_count = 5;
		int hitcount=0;
		for (int i=0;i<15;i++) {
			if (hitcount>=win_count) {
				break;
				} else {
					for (int j=0; j<15;j++) {
						if (hitcount>=win_count) {
							break;
							} else {
							if (board[i][j]=='X') {
								hitcount++;
							}else {
								hitcount=0;
					}
				}
			}
		}
	}
		for (int j=0;j<15;j++) {
			if (hitcount>=win_count) {
				break;
				} else {
					for (int i=0; i<15;i++) {
						if (hitcount>=win_count) {
							break;
							} else {
							if (board[i][j]=='X') {
								hitcount++;
							}else {
								hitcount=0;
					}
				}
			}
		}
	}
		for (int j=0;j<15;j++) {
			if (hitcount>=win_count) {
				break;
				} else {
					for (int i=0; i<15;i++) {
						if (hitcount>=win_count) {
							break;
							} else {
							if (i==j && board[i][j]=='X') {
								hitcount++;
							}else {
								if (i==j && board[i][j]!='X') {
									hitcount=0;
								}
					}
				}
			}
		}
	}
		for (int j=0;j<15;j++) {
			if (hitcount>=win_count) {
				break;
				} else {
					for (int i=0; i<15;i++) {
						if (hitcount>=win_count) {
							break;
							} else {
							if (i+j==14 && board[i][j]=='X') {
								hitcount++;
							}else {
								if (i+j==14 && board[i][j]!='X') {
									hitcount=0;
								}
					}
				}
			}
		}
	}
		if (hitcount>=win_count)
            return true;
		else return false;
	}
	public static boolean checkopponentplayer(char[][] board) {
		int win_count = 5;
		int hitcount=0;
		for (int i=0;i<15;i++) {
			if (hitcount>=win_count) {
				break;
				} else {
					for (int j=0; j<15;j++) {
						if (hitcount>=win_count) {
							break;
							} else {
							if (board[i][j]=='O') {
								hitcount++;
							}else {
								hitcount=0;
					}
				}
			}
		}
	}
		for (int j=0;j<15;j++) {
			if (hitcount>=win_count) {
				break;
				} else {
					for (int i=0; i<15;i++) {
						if (hitcount>=win_count) {
							break;
							} else {
							if (board[i][j]=='O') {
								hitcount++;
							}else {
								hitcount=0;
					}
				}
			}
		}
	}
		for (int j=0;j<15;j++) {
			if (hitcount>=win_count) {
				break;
				} else {
					for (int i=0; i<15;i++) {
						if (hitcount>=win_count) {
							break;
							} else {
							if (i==j && board[i][j]=='O') {
								hitcount++;
							}else {
								if (i==j && board[i][j]!='O') {
									hitcount=0;
								}
					}
				}
			}
		}
	}
		for (int j=0;j<15;j++) {
			if (hitcount>=win_count) {
				break;
				} else {
					for (int i=0; i<15;i++) {
						if (hitcount>=win_count) {
							break;
							} else {
							if (i+j==14 && board[i][j]=='O') {
								hitcount++;
							}else {
								if (i+j==14 && board[i][j]!='O') {
									hitcount=0;
								}
					}
				}
			}
		}
	}
		if (hitcount>=win_count)
            return true;
		else return false;
	}
	public static int possiblemoves(char[][] board) {
		int possiblemoves=0;
		for (int i=0;i<15;i++) {
			for (int j=0;j<15;j++) {
				if (board[i][j]=='_') {
					possiblemoves++;
				}
			}
		}
		return possiblemoves;
		
	}
	public static void opponentmove(char[][] board) {
		int bestscore= Integer.MIN_VALUE;
		int bestY = 0;
		int bestX = 0;
		int score;
		for (int i=0;i<15;i++) {
			for (int j=0;j<15;j++) {
				if (board[i][j]=='_') {
					board[i][j]='O';
					score = minmax(board, 0, false, i,  j);
					board[i][j]='_';
					if (score>bestscore) {
						bestscore=score;
						bestX=i;
						bestY=j;
					}
				}
			}
		}
		board[bestX][bestY]='O';
		System.out.println("Best move was: "+ bestX + bestY + "with a score of: " + bestscore);
		
	}
	public static int minmax(char[][] board,int depth,boolean isMaximizing, int currentX , int currentY) {
		if (!checkopponentplayer(board) && !checkwinplayer(board)) {
			return evaluate(board, currentX, currentY);
		}
		if (checkopponentplayer(board)) {
			return 100;
		}
		if (checkwinplayer(board)) {
			return -100;
		}
		if (possiblemoves(board)<=0) {
			System.out.println("tie");
		}
		int score;
		int bestscore = Integer.MIN_VALUE;
		if (isMaximizing) {
			for (int i=0;i<15;i++) {
				for (int j=0;j<15;j++) {
					if (board[i][j]=='_') {
						board[i][j]='O';
						score = minmax(board, depth+1, false, i, j);
						board[i][j]='_';
						if (score>bestscore) {
							bestscore=score;
						}
					}
				}
			}
			return bestscore;
		} else {
			bestscore = Integer.MAX_VALUE;
			for (int i=0;i<15;i++) {
				for (int j=0;j<15;j++) {
					if (board[i][j]=='_') {
						board[i][j]='X';
						score = minmax(board, depth+1, true, i, j);
						board[i][j]='_';
						if (score<bestscore) {
							bestscore=score;
						}
					}
				}
			}
			return bestscore;
		}
	}
	public static int evaluate(char[][] board, int currentX, int currentY) {
		int hitcount=1;
		int bestscore=0;
		
		bestscore=Math.max(hitcount, bestscore);	
		return bestscore;
	}

}
