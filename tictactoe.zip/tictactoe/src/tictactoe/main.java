package tictactoe;
import java.util.Scanner;
import java.util.Arrays;


public class main {

	public static void main(String[] args) {
		char[][] board = new char[15][15];
		Scanner move = new Scanner(System.in);
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                board[i][j] ='_';
            }
        }
        printboard(board);
        char player = 'X';
        boolean gameover=false;
        while (!gameover && possiblemoves(board) > 0) {
        		System.out.println("Enter next row move: ");
            	int moverow = move.nextInt();
            	System.out.println("Enter next collumn move: ");
            	int movecol = move.nextInt();
            	while (board[moverow][movecol]!='_') {
            		System.out.println("Enter a possible move");
        			System.out.println("Enter next row move: ");
                	moverow = move.nextInt();
                	System.out.println("Enter next collumn move: ");
                	movecol = move.nextInt();
            	}
        		if (board[moverow][movecol]=='_') {
        			board[moverow][movecol]=player;
                	if (checkwin(board,'X')) {
                		gameover=true;
                		System.out.println("Player wins!");
                		break;
                	} 
                	opponentmove(board);
                	printboard(board);
                	if (checkwin(board,'O')) {
                		gameover=true;
                		System.out.println("Computer wins!");
                		break;
                	}
        		}
        }
        if (possiblemoves(board)<=0) {
        	System.out.println("Tie!");
        }
        
       
       

	}
	public static void printboard(char[][] board) {
		 for (char[] a : board) {
	            for (char i : a) {
	                System.out.print(i + "   ");
	            }
	            System.out.println("\n");
	        }
	}
	public static boolean checkwin(char[][] board,char symbol) {
		int win_count = 5;
		int hitcount=0;
		for (int i=0;i<15;i++) {
			if (hitcount>=win_count) {
				break;
				} else {
					for (int j=0; j<15;j++) {
						if (hitcount>=win_count) {
							break;
							} else {
							if (board[i][j]==symbol) {
								hitcount++;
							}else {
								hitcount=0;
					}
				}
			}
		}
	}
		for (int j=0;j<15;j++) {
			if (hitcount>=win_count) {
				break;
				} else {
					for (int i=0; i<15;i++) {
						if (hitcount>=win_count) {
							break;
							} else {
							if (board[i][j]==symbol) {
								hitcount++;
							}else {
								hitcount=0;
					}
				}
			}
		}
	}
		//diagonal check top left -> bottom right
		for (int i=0; i<11 ; i++) {
			if (hitcount>=win_count) {
				break;
			} else {
				for (int j=0; j<11; j++) {
					hitcount=0;
					if (hitcount>=win_count) {
						break;
					} else {
						for (int k=0; k<5;k++) {
							if (hitcount>=win_count) {
								break;
							} else {
								if (board[i+k][j+k] == symbol) {
									hitcount++;
								} else {
									hitcount=0;
								}
							}
						}
					}
				}
			}
		}
		//diagonal check bottom right -> top left
		for (int i=14; i>3 ; i--) {
			if (hitcount>=win_count) {
				break;
			} else {
				for (int j=14; j>3; j--) {
					hitcount=0;
					if (hitcount>=win_count) {
						break;
					} else {
						for (int k=0; k<5;k++) {
							if (hitcount>=win_count) {
								break;
							} else {
								if (board[i-k][j-k] == symbol) {
									hitcount++;
								} else {
									hitcount=0;
								}
							}
						}
					}
				}
			}
		}
		// diagonal check bottom left -> top right
		for (int i=4; i<15 ; i++) {
			if (hitcount>=win_count) {
				break;
			} else {
				for (int j=0; j<11; j++) {
					hitcount=0;
					if (hitcount>=win_count) {
						break;
					} else {
						for (int k=0; k<5;k++) {
							if (hitcount>=win_count) {
								break;
							} else {
								if (board[i-k][j+k] == symbol) {
									hitcount++;
								} else {
									hitcount=0;
								}
							}
						}
					}
				}
			}
		}
		//check diagonal top right -> bottom left
		for (int i=0; i<11 ; i++) {
			if (hitcount>=win_count) {
				break;
			} else {
				for (int j=14; j>3; j--) {
					hitcount=0;
					if (hitcount>=win_count) {
						break;
					} else {
						for (int k=0; k<5;k++) {
							if (hitcount>=win_count) {
								break;
							} else {
								if (board[i+k][j-k] == symbol) {
									hitcount++;
								} else {
									hitcount=0;
								}
							}
						}
					}
				}
			}
		}
		
		if (hitcount>=win_count)
            return true;
		else return false;
	}
	
	public static int possiblemoves(char[][] board) {
		int possiblemoves=0;
		for (int i=0;i<15;i++) {
			for (int j=0;j<15;j++) {
				if (board[i][j]=='_') {
					possiblemoves++;
				}
			}
		}
		return possiblemoves;	
	}
	
	public static void opponentmove(char[][] board) {
		int bestscore= -500;
		int bestY = 0;
		int bestX = 0;
		int score;
		for (int i=0;i<15;i++) {
			for (int j=0;j<15;j++) {
				if (board[i][j]=='_') {
					board[i][j]='O';
					score = minmax(board, 0, false, 3, -3);
					board[i][j]='_';
					if (score>bestscore) {
						bestscore=score;
						bestX=i;
						bestY=j;
					}
				}
			}
		}
		board[bestX][bestY]='O';
		System.out.println("Best move was: "+ bestX +" "+ bestY + " with a score of: " + bestscore);
		
	}
	public static int minmax(char[][] board,int depth,boolean isMaximizing,int Alpha, int Beta) {
		if (checkwin(board,'X')) {
			return -10+depth;
		}
		if (checkwin(board,'O')) {
			return 10-depth;
		}
		if (depth>=3) {
			return 0;
		}
		int score;
		int bestscore = Integer.MIN_VALUE;
		if (isMaximizing) {
			for (int i=0;i<15;i++) {
				for (int j=0;j<15;j++) {
					if (board[i][j]=='_') {
						board[i][j]='O';
						score = minmax(board, depth+1, false, 3, -3);
						board[i][j]='_';
						if (score>bestscore) {
							bestscore=score;
						}
						Alpha = Math.max(Alpha, score);
						if (Beta<=Alpha) {
							break;
						}
					}
				}
				if (depth==0){
					return 1000;
				}
			}
			return bestscore;
		} else {
			bestscore = Integer.MAX_VALUE;
			for (int i=0;i<15;i++) {
				for (int j=0;j<15;j++) {
					if (board[i][j]=='_') {
						board[i][j]='X';
						score = minmax(board, depth+1, true, 3, -3);
						board[i][j]='_';
						bestscore=Math.min(score,bestscore);
						Beta = Math.min(score, Beta);
						if (Beta<=Alpha) {
							break;
						}
					}
				}
			}
			return bestscore;
		}
	}
}
